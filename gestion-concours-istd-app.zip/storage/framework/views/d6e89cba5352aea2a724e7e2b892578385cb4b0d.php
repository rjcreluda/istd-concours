

<?php $__env->startSection('title', 'Fiche de presence'); ?>

<?php $__env->startSection('style'); ?>
<style>
    .dt-buttons{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<!-- Page Content -->
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.page_title', ['title' => 'Fiche de presence'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.row -->
    <?php
        $doc_title = 'Candidats au centres '.$centre->lieu
    ?>
    <!-- .row -->
    <div class="row">
        <div class="col-md-12">
            <div class="white-box">
                <div class="d-flex justify-content-between mb-3">
                    <div>
                        <span class="pr-3">Choisir un centre d'examen</span>
                        <select name="centre_id" id="centres">
                            <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"
                            <?php if( $p->id == $centre->id): ?>
                            selected
                            <?php endif; ?>
                            ><?php echo e($p->lieu); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if(isset( $salle )): ?>
                        <span class="pr-3 pl-2">Salle</span>
                        <select name="salle_id" id="salles">
                            <?php $__currentLoopData = $salles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"
                            <?php if( $s->id == $salle->id): ?>
                            selected
                            <?php endif; ?>
                            ><?php echo e($s->reference); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                    </div>
                    <?php if(isset( $salle )): ?>
                        <a href="<?php echo e(route('print.preview')); ?>?type=fiche-presence&centre_id=<?php echo e($centre->id); ?>&salle_id=<?php echo e($salle->id); ?>" class="btn btn-default">Imprimer la fiche</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('print.preview')); ?>?type=fiche-presence&centre_id=<?php echo e($centre->id); ?>" class="btn btn-default">Imprimer la fiche</a>
                    <?php endif; ?>

                </div>
                

                <div class="table-responsive">
                    <table id="tableData" class="display nowrap" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <?php if( $concour_active->num_auto ): ?>
                                <th>No.Inscription</th>
                                <?php endif; ?>
                                <th>Nom et Prénom</th>
                                <th>Parcour</th>
                                <th>Emargement</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $candidats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if( $concour_active->num_auto ): ?>
                                <td><?php echo e($c->numInscription); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($c->nom); ?> <?php echo e($c->prenom); ?></td>
                                <td><?php echo e($c->parcour->code); ?></td>
                                <td></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <?php if( $concour_active->num_auto ): ?>
                                <th>No.Inscription</th>
                                <?php endif; ?>
                                <th>Nom et Prénom</th>
                                <th>Parcour</th>
                                <th>Emargement</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScript'); ?>
    ##parent-placeholder-8c5bdf56ea289500a85e2f281fc567c9842dac32##
    <script>
        /* Selection Centre */
        $('#centres').change( function() {
            let centre_id = $(this).val();
            let current_url = window.location.href;
            let url = window.location.origin + '/dashboard/candidats/fiche/presence' + '/' + centre_id;
            window.location.href = url;
        });

        $('#salles').change( function() {
            let salle_id = $(this).val();
            console.log(`Salle id: ${salle_id}`)
            let current_url = window.location.href;
            let sub_url = current_url.substring(0, current_url.lastIndexOf('/'))
            console.log(`Sub url: ${sub_url}`)
            let url = sub_url + '/' + salle_id;
            window.location.href = url;
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-concours-istd-app\resources\views/fiche-presence/fiche.blade.php ENDPATH**/ ?>