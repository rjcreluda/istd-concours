

<!-- Page Content -->
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.page_title', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.row -->
    <!-- .row -->
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="white-box">
                <div class="r-icon-stats">
                    <i class="ti-user bg-megna"></i>
                    <div class="bodystate">
                        <h4>
                            <a href="/candidats/">
                                TIM
                            </a>
                        </h4>
                        <span class="text-muted">
                            <a href="#"></a>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScript'); ?>
    ##parent-placeholder-8c5bdf56ea289500a85e2f281fc567c9842dac32##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-concours-istd-app\resources\views/dashboard.blade.php ENDPATH**/ ?>