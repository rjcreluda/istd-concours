<?php if( $errors->any() ): ?>
  <div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
<?php if( session('success') ): ?>
  <div class="alert alert-success">
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if( session('error') ): ?>
  <div class="alert alert-danger">
    <?php echo e(session('error')); ?>

  </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\gestion-concours-istd-app\resources\views/partials/message.blade.php ENDPATH**/ ?>