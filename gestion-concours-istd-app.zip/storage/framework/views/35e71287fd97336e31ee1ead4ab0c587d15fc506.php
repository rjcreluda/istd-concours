<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse slimscrollsidebar">
        <ul class="nav" id="side-menu">
            <li> <a href="/" class="waves-effect"><i class="ti-home mr-1"></i> <span class="hide-menu"> Accueil </span></a></li>
            <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-settings mr-2" data-icon="v"></i> <span class="hide-menu">Le concours<span class="fa arrow"></span></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="<?php echo e(route('concours.index')); ?>">Liste</a></li>
                        <li><a href="<?php echo e(route('parcours.index')); ?>">Parcours</a></li>
                        <li><a href="<?php echo e(route('salles.index')); ?>">Salles</a></li>
                        <li><a href="<?php echo e(route('settings.index')); ?>">Notes et Deliberation</a></li>
                    </ul>
                </li>

                <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-folder mr-2" data-icon="v"></i> <span class="hide-menu">Resultats<span class="fa arrow"></span></span></a>
                    <ul class="nav nav-second-level">
                        <li> <a href="<?php echo e(route('resultats.brute')); ?>">Brute</a></li>
                        <li> <a href="<?php echo e(route('resultats.deliberation')); ?>">Deliberation</a></li>
                        
                    </ul>
                </li>
            <?php endif; ?>

            <li><a href="javascript:void(0);" class="waves-effect"><i data-icon=")" class="ti-user mr-2"></i> <span class="hide-menu">Candidats<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <li><a href="<?php echo e(route('candidats.create')); ?>">Ajouter nouveau</a></li>
                    <?php $__currentLoopData = $ecoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('candidats.ecole', ['ecole' => $ecole->id])); ?>"><?php echo e($ecole->code); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('salles.list')); ?>">Liste par salle</a></li>
                    <li><a href="<?php echo e(route('fiche.centres')); ?>">Fiche de presence</a></li>
                    <li><a href="<?php echo e(route('candidats.attribution')); ?>">Attribution</a></li>
                </ul>
            </li>

            <li><a href="javascript:void(0);" class="waves-effect"><i data-icon=")" class="ti-calendar mr-2"></i> <span class="hide-menu">Convocation<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <li><a href="<?php echo e(route('convocation.par_jour')); ?>">Imprimer par jour</a></li>
                    <li><a href="<?php echo e(route('convocation.liste_parcours')); ?>">Imprimer un à un</a></li>
                    <li><a href="<?php echo e(route('convocation.par_date')); ?>">Imprimer par date</a></li>
                </ul>
            </li>

            <li class="m-l-5 font-weight-bold">EGI</li>
            <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-calendar p-r-10"></i> <span class="hide-menu">Notes EGI<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <?php $__currentLoopData = $parcours_egi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('notes.transcription', ['parcour' => $p->id])); ?>"><?php echo e($p->code); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

            <li class="m-l-5 font-weight-bold">EGMCS</li>
            <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-calendar p-r-10"></i> <span class="hide-menu">Notes EGMCS<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <?php $__currentLoopData = $parcours_egmcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('notes.transcription', ['parcour' => $p->id])); ?>"><?php echo e($p->code); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

            <li class="m-l-5 font-weight-bold">EGCN</li>
            <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-calendar p-r-10"></i> <span class="hide-menu">Notes EGCN<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <?php $__currentLoopData = $parcours_egcn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('notes.transcription', ['parcour' => $p->id])); ?>"><?php echo e($p->code); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

            <li><a href="javascript:void(0);" class="waves-effect"><i class="ti-settings mr-2" data-icon="v"></i> <span class="hide-menu">Paramètres<span class="fa arrow"></span></span></a>
                <ul class="nav nav-second-level">
                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                        <li> <a href="<?php echo e(route('users.index')); ?>">Utilisateurs</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route('users.show', ['user' => auth()->user()->id])); ?>">Mon compte</a></li>
                    <?php endif; ?>
                </ul>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\gestion-concours-istd-app\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>