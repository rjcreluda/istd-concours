

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('style'); ?>
<style>
    .dt-buttons{ display: none; }
</style>
<?php $__env->stopSection(); ?>

<!-- Page Content -->
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.page_title', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.row -->
    <?php
        $doc_title = 'Convocation'
    ?>
    <!-- .row -->
    <div class="row">
        <div class="col-md-12">
            <div class="white-box">

                    <div class="table-responsive mt-3">
                        <table id="tableData" class="display nowrap table table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Parcours</th>
                                    <th>Nombre des candidats</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $parcours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($p->nom); ?></td>
                                <td><?php echo e($p->nbr_candidats); ?></td>
                                <td>
                                    <div class="btn-group">
                                    <a href="<?php echo e(route('convocation.preview', ['parcour' => $p->id])); ?>">
                                        <button type="button" class="btn btn-sm btn-outline-info btnVoirProfile"><i class="fa fa-eye"></i></button>
                                    </a>
                                    </div>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Parcours</th>
                                    <th>Nombre</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerScript'); ?>
    ##parent-placeholder-8c5bdf56ea289500a85e2f281fc567c9842dac32##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-concours-istd-app\resources\views/convocation/par_jour.blade.php ENDPATH**/ ?>