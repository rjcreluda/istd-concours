<footer class="footer text-center"> 
	<?php $annee = date('Y'); echo $annee; ?> &copy; Gestion Concours d'entrée pour l'Institut Supérieur de Technologie D'Antsiranana 
</footer>
</div>