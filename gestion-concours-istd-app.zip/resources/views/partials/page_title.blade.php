<div class="row bg-title">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <h4 class="page-title">{{ $title }}</h4>
    </div>
    <div class="col-lg-6 col-sm-6 col-md-8 col-xs-12">
        <ol class="breadcrumb">
            <li><a href="#"></a></li>
        </ol>
    </div>
</div>