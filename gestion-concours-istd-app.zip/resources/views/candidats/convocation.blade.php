<!DOCTYPE html>
<html>
<head>
  <title>Convocation</title>
  <!-- Bootstrap Core CSS -->
  <link href="/resources/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <p>
          REPOBLIKAN'I MADAGASIKARA<br>
        Fitiavana-Tanindrazana-Fandrosoana
        </p>
        <p>
          <strong>MINISTERE DE L’ENSEIGNEMENT SUPERIEUR ET DE LA RECHERCHE SCIENTIFIQUE</strong>
        </p>
        <p class="lead">
          <strong>INSTITUT SUPERIEUR DE TECHNOLOGIE D’ANTSIRANANA</strong>
        </p>
        <div class="row">
          <div class="col-md-4">B.P. 509 Antsiranana - 201</div>
          <div class="col-md-4">istd@ist-antsiranana.mg</div>
          <div class="col-md-4">www.ist-antsiranana.mg</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>